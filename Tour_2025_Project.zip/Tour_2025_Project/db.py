from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship
from db import Base

# Модель для користувачів
class Customer(Base):
    __tablename__ = 'customers'

    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(50), unique=True, nullable=False)
    password = Column(String(60), nullable=False)
    is_admin = Column(Boolean, default=False)

# Модель для турів
class TravelPackage(Base):
    __tablename__ = 'travel_packages'

    id = Column(Integer, primary_key=True)
    name = Column(String(50), nullable=False)
    city = Column(String(50), nullable=False)
    days = Column(Integer, nullable=False)
    price = Column(Integer, nullable=False)
    date = Column(DateTime, nullable=False)
    image_path = Column(Text, default="/static/images/default.jpg")

# Модель для бронювання турів
class Booking(Base):
    __tablename__ = 'bookings'

    id = Column(Integer, primary_key=True)
    customer_id = Column(Integer, ForeignKey('customers.id'), nullable=False)
    package_id = Column(Integer, ForeignKey('travel_packages.id'), nullable=False)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=False)

    customer = relationship('Customer', back_populates='bookings')
    travel_package = relationship('TravelPackage', back_populates='bookings')

Customer.bookings = relationship('Booking', back_populates='customer')
TravelPackage.bookings = relationship('Booking', back_populates='travel_package')
