
import datetime
from functools import wraps
from fastapi import FastAPI, Request, Form, Depends, File, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from db import get_db, User, Tour, Buy
from const import TOUR_HTML
from config import app, templates


@app.get('/', response_class=HTMLResponse)
def index(request: Request, db: Session = Depends(get_db)):
    tours = db.query(Tour).all()
    user = db.query(User).get(1)
    user.is_admin = True
    db.commit()
    return templates.TemplateResponse('index.html', {'tours': tours, 'request': request})


@app.post('/login')
async def login(request: Request, email: str = Form(), password: str = Form(), db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=email, password=password).first()
    if user is None:
        return RedirectResponse(url='/login?after_fail=True', status_code=302)

    request.session['user_id'] = user.id
    request.session['is_auth'] = True
    return RedirectResponse('/', status_code=303)


@app.get('/login', response_class=HTMLResponse)
def login(request: Request, after_fail: bool = False):
    context = {'request': request}
    if after_fail:
        context['message'] = 'Email or password is not correct'
    return templates.TemplateResponse('login.html', context)


@app.get('/logout', response_class=HTMLResponse)
def logout(request: Request):
    del request.session['user_id']
    request.session['is_auth'] = False
    return RedirectResponse('/', status_code=303)


def login_required(view):
    @wraps(view)
    async def wrap(request: Request, *args, **kwargs):
        if not request.session.get('is_auth', False):
            return RedirectResponse('/login', status_code=303)
        return await view(request, *args, **kwargs)
    return wrap


@app.post('/create-tour')
@login_required
async def create_tour(
        request: Request,
        name: str = Form(),
        city: str = Form(),
        days: int = Form(),
        price: int = Form(),
        date: str = Form(),
        images: UploadFile = File(),
        db: Session = Depends(get_db)):

    user = db.query(User).get(request.session['user_id'])
    if not user.is_admin:
        return RedirectResponse('/login', status_code=303)

    date = datetime.datetime.strptime(date, '%Y-%m-%d')
    tour = Tour(name=name, city=city, days=days, price=price, date=date)
    db.add(tour)
    db.commit()
    db.refresh(tour)
    with open(f'static/images/{tour.id}.jpg', 'wb') as image:
        content = await images.read()
        image.write(content)
        tour.images = f'/static/images/{tour.id}.jpg'
        db.commit()
        db.refresh(tour)
    return {'id': tour.id}


@app.get('/register', response_class=HTMLResponse)
def reg(request: Request, db: Session = Depends(get_db)):
    users = db.query(User).all()
    return templates.TemplateResponse('register.html', {'users': users, 'request': request})


@app.post('/register')
def register(request: Request, username: str = Form(), email: str = Form(), password: str = Form(), db: Session = Depends(get_db)):
    user = User(username=username, email=email, password=password)
    db.add(user)
    db.commit()
    db.refresh(user)
    return RedirectResponse('/', status_code=303)


@app.get('/buy', response_class=HTMLResponse)
def index(request: Request, db: Session = Depends(get_db)):
    tours = db.query(Tour).all()
    return templates.TemplateResponse('index.html', {'tours': tours, 'request': request})


@app.post('/buy-tour')
def buy_tour(user_id: str = Form(), tour_id: str = Form(), start_at: str = Form(), end_at: str = Form(), db: Session = Depends(get_db)):
    start_at = datetime.datetime.strptime(start_at, '%Y-%m-%d')
    end_at = datetime.datetime.strptime(end_at, '%Y-%m-%d')
    buy = Buy(user_id=user_id, tour_id=tour_id, start_at=start_at, end_at=end_at)
    db.add(buy)
    db.commit()
    db.refresh(buy)
    return {}


@app.post('/search')
def search(search: str = Form(), db: Session = Depends(get_db)):
    tours = db.query(Tour).filter_by(name=search)
    result = ""
    for tour in tours:
        result += TOUR_HTML.format(tour_id=tour.id, tour_name=tour.name, tour_city=tour.city, tour_days=tour.days, tour_price=tour.price, tour_date=tour.date, tour_images=tour.images)
    return {'tours': result}
