# Travel Tour Web Application

This is a simple web application for booking tours to different destinations across the world. It is built with FastAPI and SQLite. Users can register, log in, view available tours, and purchase them. Admin users can add new tours.

## Features:
- User Registration
- User Login
- View Available Tours
- Purchase Tours
- Admin Dashboard to Add Tours

## Requirements:
- Python 3.8+
- FastAPI
- Uvicorn
- SQLAlchemy

## Installation:

### 1. Clone the repository:
```bash
git clone https://github.com/yourusername/travel-tour.git
cd travel-tour
